package com.example.tubes1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DokterPresenter {
    protected List<Dokter> dokters;
    protected IFragmentDokter ui;

    public DokterPresenter(IFragmentDokter view){
        this.dokters = new ArrayList<>();
        this.ui = view;
    }

    @SuppressWarnings("unused")
    public void loadData(){
        this.dokters.addAll(Arrays.asList(DokterList.dokterObjectArr));
        this.ui.UpdateList(this.dokters);
    }

    @SuppressWarnings("unused")
    public void addNew(String namaDokter, String jenisDokter){
        Dokter item = new Dokter(namaDokter,jenisDokter);
        this.dokters.add(item);
        this.ui.UpdateList(this.dokters);
        this.ui.resetAddForm();
    }

    public void deleteItem(int i){
        this.dokters.remove(i);
        this.ui.UpdateList(this.dokters);
    }

    public interface IFragmentDokter{
        void UpdateList(List<Dokter> data);
        void resetAddForm();
    }
}
