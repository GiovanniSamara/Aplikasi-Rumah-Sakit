package com.example.tubes1;

public class Dokter {
    private String namaDokter;
    private String jenisDokter;

    public Dokter(String namaDokter, String jenisDokter){
        this.namaDokter = namaDokter;
        this.jenisDokter = jenisDokter;
    }

    @SuppressWarnings("unused")
    public void setNamaDokter(String namaDokter) {
        this.namaDokter = namaDokter;
    }

    @SuppressWarnings("unused")
    public void setJenisDokter(String jenisDokter) {
        this.jenisDokter = jenisDokter;
    }

    public String getNamaDokter() {
        return this.namaDokter;
    }

    public String getJenisDokter() {
        return this.jenisDokter;
    }
}
