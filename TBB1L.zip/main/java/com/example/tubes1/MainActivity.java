package com.example.tubes1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

/*
Nama : Giovanni Samara Gading Matasik
NPM : 6181801050
 */

public class MainActivity extends AppCompatActivity implements FragmentListener{
    private MainFragment main;
    private BuatPertemuanFragment buatPertemuan;
    private PertemuanFragment pertemuanF;
    private DokterFragment dokterF;
    private Toolbar toolbar;
    private FragmentManager fragmentManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.main = MainFragment.newInstance();
        this.buatPertemuan = BuatPertemuanFragment.newInstance();
        this.pertemuanF = PertemuanFragment.newInstance();
        this.dokterF = DokterFragment.newInstance();
        this.fragmentManager = this.getSupportFragmentManager();


        this.toolbar = findViewById(R.id.toolbar);
        this.setSupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);

        ActionBarDrawerToggle dt = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.openDrawer, R.string.closeDrawer);
        drawer.addDrawerListener(dt);
        dt.syncState();

        FragmentTransaction ft = this.fragmentManager.beginTransaction();
        ft.add(R.id.fragment_container, this.main).addToBackStack(null).commit();
    }

    public void changePage(int page) {
        FragmentTransaction ft = this.fragmentManager.beginTransaction();
        if(page == 1){
            ft.replace(R.id.fragment_container, this.main).addToBackStack(null);
        } else if(page == 2){
            ft.replace(R.id.fragment_container, this.pertemuanF).addToBackStack(null); //nanti ganti ini jadi list pertemuan untuk page 2, bikin page 4 untuk buatPertemuan
        }else if(page == 3){
            ft.replace(R.id.fragment_container, this.dokterF).addToBackStack(null);
        }else if(page == 4){
            ft.replace(R.id.fragment_container, this.buatPertemuan).addToBackStack(null);
        }
        ft.commit();
    }

    public void closeApplication(){
        this.moveTaskToBack(true);
        this.finish();
    }

    public void onTextChange(String number){

    }

}