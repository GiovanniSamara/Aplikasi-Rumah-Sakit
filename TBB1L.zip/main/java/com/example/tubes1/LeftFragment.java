package com.example.tubes1;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

public class LeftFragment extends Fragment implements View.OnClickListener{
    public FragmentListener fragmentListener;
    public TextView home, pertemuan, dokter, exit;


    public LeftFragment() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_left, container, false);

        this.home = view.findViewById(R.id.homeButton);
        this.pertemuan = view.findViewById(R.id.pertemuanButton);
        this.dokter = view.findViewById(R.id.dokterButton);
        this.exit = view.findViewById(R.id.exitButton);

        this.home.setOnClickListener(this);
        this.pertemuan.setOnClickListener(this);
        this.dokter.setOnClickListener(this);
        this.exit.setOnClickListener(this);

        return view;
    }

    public void onAttach(Context context){
        super.onAttach(context);
        if(context instanceof FragmentListener){
            this.fragmentListener = (FragmentListener) context;
        } else{
            throw new ClassCastException(context.toString() + " must implement FragmentListener");
        }
    }

    @Override
    public void onClick(View view) {
        if(view == this.home){
            fragmentListener.changePage(1);
        } else if(view == this.pertemuan){
            fragmentListener.changePage(2);
        } else if(view == this.dokter){
            fragmentListener.changePage(3);
        }else if(view == this.exit) {
            fragmentListener.closeApplication();
        }
    }
}
