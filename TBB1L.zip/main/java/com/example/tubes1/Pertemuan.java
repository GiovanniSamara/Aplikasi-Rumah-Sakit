package com.example.tubes1;

public class Pertemuan {
    private String namaDokterPertemuan;
    private String jenisDokterPertemuan;
    private String keluhanPertemuan;
    private String tanggalPertemuan;
    private String waktuPertemuan;

    public Pertemuan(String namaDokterPertemuan, String jenisDokterPertemuan, String keluhanPertemuan, String tanggalPertemuan, String waktuPertemuan){
        this.namaDokterPertemuan = namaDokterPertemuan;
        this.jenisDokterPertemuan = jenisDokterPertemuan;
        this.keluhanPertemuan = keluhanPertemuan;
        this.tanggalPertemuan = tanggalPertemuan;
        this.waktuPertemuan = waktuPertemuan;
    }

    @SuppressWarnings("unused")
    public void setNamaDokterPertemuan(String namaDokterPertemuan){
        this.namaDokterPertemuan = namaDokterPertemuan;
    }

    @SuppressWarnings("unused")
    public void setJenisDokterPertemuan(String jenisDokterPertemuan){
        this.jenisDokterPertemuan = jenisDokterPertemuan;
    }

    @SuppressWarnings("unused")
    public void setKeluhanPertemuan(String keluhanPertemuan){
        this.keluhanPertemuan = keluhanPertemuan;
    }

    @SuppressWarnings("unused")
    public void setTanggalPertemuan(String tanggalPertemuan){
        this.tanggalPertemuan = tanggalPertemuan;
    }

    @SuppressWarnings("unused")
    public void setWaktuPertemuan(String waktuPertemuan){
        this.waktuPertemuan = waktuPertemuan;
    }

    public String getNamaDokterPertemuan(){
        return this.namaDokterPertemuan;
    }

    public String getJenisDokterPertemuan(){
        return this.jenisDokterPertemuan;
    }

    public String getKeluhanPertemuan(){
        return this.keluhanPertemuan;
    }

    public String getTanggalPertemuan(){
        return this.tanggalPertemuan;
    }

    public String getWaktuPertemuan(){
        return this.waktuPertemuan;
    }
}
