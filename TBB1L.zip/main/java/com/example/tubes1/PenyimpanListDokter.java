package com.example.tubes1;

import android.content.Context;
import android.content.SharedPreferences;

public class PenyimpanListDokter {
    protected SharedPreferences sharedPref;
    protected final static String NAMA_SHARED_PREF = "sp_list_dokter";
    protected final static String KEY_NAMA = "NAMA";
    protected final static String KEY_JENIS = "JENIS";

    public PenyimpanListDokter (Context context){
        this.sharedPref = context.getSharedPreferences(NAMA_SHARED_PREF, 0);
    }

    public void saveNama(String nama){
        SharedPreferences.Editor editor = this.sharedPref.edit();
        editor.putString(KEY_NAMA, nama);
        editor.commit();
    }

    public String getNama(){
        return sharedPref.getString(KEY_NAMA, "");
    }

    public void saveJenis(String jenis){
        SharedPreferences.Editor editor = this.sharedPref.edit();
        editor.putString(KEY_JENIS, jenis);
        editor.commit();
    }

    public String getJenis(){
        return sharedPref.getString(KEY_JENIS, "");
    }
}
