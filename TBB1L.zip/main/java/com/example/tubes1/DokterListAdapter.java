package com.example.tubes1;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class DokterListAdapter extends BaseAdapter {
    private List<Dokter> dokterList;
    public final DokterFragment dokterFragment;
    public DokterPresenter p;

    public DokterListAdapter(DokterFragment dokterFragment, DokterPresenter p){
        this.dokterFragment = dokterFragment;
        this.p = p;
        this.dokterList = new ArrayList<>();
    }

    @Override
    public int getCount() {
        return dokterList.size();
    }

    @Override
    public Object getItem(int i) {
        return dokterList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(final int i, View convertView, ViewGroup parent) {
        convertView = LayoutInflater.from(dokterFragment.getContext()).inflate(R.layout.item_list_dokter,parent,false);
        final Dokter currentDokter = (Dokter) this.getItem(i);

        ViewHolder viewHolder = new ViewHolder(convertView, i, this.p);
        viewHolder.updateView(currentDokter);

        return convertView;
    }

    public void updateList(List<Dokter> newList){
        this.dokterList = newList;
    }


    private class ViewHolder {
        protected TextView namaDokter;
        protected TextView jenisDokter;
        protected ImageButton delete;
        protected int i;
        public DokterPresenter p;

        public ViewHolder(View view, int i, DokterPresenter p) {
            this.namaDokter = view.findViewById(R.id.tv_nama_dokter);
            this.jenisDokter = view.findViewById(R.id.tv_jenis_dokter);
            this.delete = view.findViewById(R.id.tv_dokter_delete);
            this.i = i;
            this.p = p;
        }

        public void updateView(final Dokter dokter) {
            this.namaDokter.setText(dokter.getNamaDokter());
            this.jenisDokter.setText(dokter.getJenisDokter());
            this.delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(view == delete){
                        p.deleteItem(i);
                        notifyDataSetChanged();
                    }
                }
            });
        }
    }
}
