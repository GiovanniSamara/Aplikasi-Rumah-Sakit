package com.example.tubes1;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import java.util.Arrays;
import java.util.List;

public class PertemuanFragment extends Fragment implements PertemuanPresenter.IFragmentPertemuan {
    FragmentListener fragmentListener;
    PertemuanListAdapter adapter;
    PertemuanPresenter pp;

    public PertemuanFragment(){

    }

    public static PertemuanFragment newInstance() {
        PertemuanFragment fragment = new PertemuanFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.fragment_pertemuan, container, false);
        ListView listPertemuan = view.findViewById(R.id.lstPertemuan);

        Bundle bundle = getArguments();

        String namaDokterPertemuanI = bundle.getString("nama");
        String jenisDokterPertemuanI = bundle.getString("jenis");
        String keluhanPertemuanI = bundle.getString("keluhan");
        String tanggalPertemuanI = bundle.getString("tanggal");
        String waktuPertemuanI = bundle.getString("waktu");

        this.pp = new PertemuanPresenter(this);
        List<Pertemuan> pertemuans = Arrays.asList(PertemuanList.pertemuanObjectArr);
        this.adapter = new PertemuanListAdapter(this, pp);
        listPertemuan.setAdapter(adapter);
        pp.loadData();

        pp.addNew(namaDokterPertemuanI, jenisDokterPertemuanI, keluhanPertemuanI, tanggalPertemuanI, waktuPertemuanI);

        return view;
    }

    public void onAttach(Context context){
        super.onAttach(context);
        if(context instanceof FragmentListener){
            this.fragmentListener = (FragmentListener) context;
        } else{
            throw new ClassCastException(context.toString() + " must implement FragmentListener");
        }
    }

    @Override
    public void UpdateList(List<Pertemuan> data) {
        adapter.updateList(data);
        adapter.notifyDataSetChanged();
    }

    @Override
    public void resetAddForm() {

    }
}
