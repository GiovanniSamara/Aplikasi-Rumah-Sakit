package com.example.tubes1;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class BuatPertemuanFragment extends Fragment {
    private FragmentListener fragmentListener;
    private EditText namaDokterPertemuan, jenisDokterPertemuan, keluhanPertemuan, tanggalPertemuan, waktuPertemuan;
    private Button simpanPertemuan, simpanText;
    private PenyimpanListPertemuan pencatat;

    public BuatPertemuanFragment(){
    }

    public static BuatPertemuanFragment newInstance() {
        BuatPertemuanFragment fragment = new BuatPertemuanFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView (LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_buat_pertemuan, container, false);
        this.namaDokterPertemuan = view.findViewById(R.id.et_nama_pertemuan);
        this.jenisDokterPertemuan = view.findViewById(R.id.et_jenis_pertemuan);
        this.keluhanPertemuan = view.findViewById(R.id.et_keluhan_pertemuan);
        this.tanggalPertemuan = view.findViewById(R.id.et_tanggal_pertemuan);
        this.waktuPertemuan = view.findViewById(R.id.et_waktu_pertemuan);
        this.simpanPertemuan = view.findViewById(R.id.btn_simpan_pertemuan);
        //this.simpanText = view.findViewById(R.id.btn_simpan_pertemuan_text);
        //pencatat = new PenyimpanListPertemuan(this);

        /*this.simpanText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(view == simpanText){
                    writeData();
                }
            }
        });*/

        this.simpanPertemuan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle bundle = new Bundle();
                bundle.putString("nama", namaDokterPertemuan.getText().toString());
                bundle.putString("jenis", jenisDokterPertemuan.getText().toString());
                bundle.putString("keluhan", keluhanPertemuan.getText().toString());
                bundle.putString("waktu", waktuPertemuan.getText().toString());
                bundle.putString("tanggal", tanggalPertemuan.getText().toString());

                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

                PertemuanFragment pertemuanFragment = new PertemuanFragment();
                pertemuanFragment.setArguments(bundle);

                fragmentTransaction.replace(R.id.fragment_container, pertemuanFragment);
                fragmentTransaction.commit();

                Pertemuan pertemuan = new Pertemuan("dr Mike", "Internis", "Sakit ginjal", "1 November 2022", "13:00" );
            }
        });

        return view;
    }

/*
    @Override
    public void onPause(){
        super.onPause();
        this.pencatat.saveNama(this.namaDokterPertemuan.getText().toString());
        this.pencatat.saveJenis(this.jenisDokterPertemuan.getText().toString());
        this.pencatat.saveKeluhan(this.keluhanPertemuan.getText().toString());
        this.pencatat.saveTanggal(this.tanggalPertemuan.getText().toString());
        this.pencatat.saveWaktu(this.waktuPertemuan.getText().toString());
    }

    @Override
    public void onResume(){
        super.onResume();
        this.namaDokterPertemuan.setText(this.pencatat.getNama());
        this.jenisDokterPertemuan.setText(this.pencatat.getJenis());
        this.keluhanPertemuan.setText(this.pencatat.getKeluhan());
        this.tanggalPertemuan.setText(this.pencatat.getTanggal());
        this.waktuPertemuan.setText(this.pencatat.getWaktu());
    }

    public void writeData(){
        try {
            FileOutputStream fileOutputStream = getActivity().openFileOutput("MyFile", Context.MODE_PRIVATE);
            fileOutputStream.write(namaDokterPertemuan.getText().toString().getBytes());
            fileOutputStream.write(jenisDokterPertemuan.getText().toString().getBytes());
            fileOutputStream.write(keluhanPertemuan.getText().toString().getBytes());
            fileOutputStream.write(tanggalPertemuan.getText().toString().getBytes());
            fileOutputStream.write(waktuPertemuan.getText().toString().getBytes());
        }catch (FileNotFoundException e){
            e.printStackTrace();
        }catch (IOException e){
            e.printStackTrace();
        }
    }
*/

    public void onAttach(Context context){
        super.onAttach(context);
        if(context instanceof FragmentListener){
            this.fragmentListener = (FragmentListener) context;
        } else{
            throw new ClassCastException(context.toString() + " must implement FragmentListener");
        }
    }
}