package com.example.tubes1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PertemuanPresenter{
    protected List<Pertemuan> pertemuans;
    protected IFragmentPertemuan ui;

    public PertemuanPresenter(IFragmentPertemuan view){
        this.pertemuans = new ArrayList<>();
        this.ui = view;
    }

    @SuppressWarnings("unused")
    public void loadData(){
        this.pertemuans.addAll(Arrays.asList(PertemuanList.pertemuanObjectArr));
        this.ui.UpdateList(this.pertemuans);
    }

    @SuppressWarnings("unused")
    public void addNew(String namaDokterPertemuan, String jenisDokterPertemuan, String keluhanPertemuan, String tanggalPertemuan, String waktuPertemuan){
        Pertemuan item = new Pertemuan(namaDokterPertemuan,jenisDokterPertemuan, keluhanPertemuan, tanggalPertemuan, waktuPertemuan);
        this.pertemuans.add(item);
        this.ui.UpdateList(this.pertemuans);
        this.ui.resetAddForm();
    }

    public void deleteItem(int i){
        this.pertemuans.remove(i);
        this.ui.UpdateList(this.pertemuans);
    }

    public interface IFragmentPertemuan{
        void UpdateList(List<Pertemuan> data);
        void resetAddForm();
    }
}
