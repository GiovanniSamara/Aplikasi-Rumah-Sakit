package com.example.tubes1;

public class DokterList {
    public static Dokter[] dokterObjectArr = {
            new Dokter("dr Mike","Internis"),
            new Dokter("dr James","Anak"),
            new Dokter("dr Kevin","Ortopedis"),
            new Dokter("dr Nicole","Kandungan"),
            new Dokter("dr Anisa","Jantung")
    };
}
