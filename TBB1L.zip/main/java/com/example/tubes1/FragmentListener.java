package com.example.tubes1;

public interface FragmentListener {
    void changePage(int page);
    void closeApplication();
    void onTextChange(String number);
}
