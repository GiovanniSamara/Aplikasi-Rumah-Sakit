package com.example.tubes1;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class PertemuanListAdapter extends BaseAdapter {
    private List<Pertemuan> pertemuans;
    public final PertemuanFragment pertemuanFragment;
    private PertemuanPresenter pp;


    public PertemuanListAdapter(PertemuanFragment pertemuanFragment, PertemuanPresenter pp){
        this.pertemuanFragment = pertemuanFragment;
        this.pp = pp;
        this.pertemuans = new ArrayList<Pertemuan>();
    }


    @Override
    public int getCount() {
        return pertemuans.size();
    }

    @Override
    public Object getItem(int i) {
        return pertemuans.get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(final int i, View convertView, ViewGroup parent) {
        convertView = LayoutInflater.from(pertemuanFragment.getContext()).inflate(R.layout.item_list_pertemuan, parent, false);
        final Pertemuan currentPertemuan = (Pertemuan) this.getItem(i);

        ViewHolder viewHolder = new ViewHolder(convertView,i, this.pp);
        viewHolder.updateView(currentPertemuan);

        return convertView;
    }


    public void updateList(List<Pertemuan> newList){
        this.pertemuans = newList;
    }

    private class ViewHolder{
        public TextView namaDokterText, jenisDokterText, keluhanText, tanggalText, waktuText;
        public ImageButton delete;
        public int i;
        public PertemuanPresenter pp;

        public ViewHolder(View view, int i, PertemuanPresenter pp){
            this.namaDokterText = view.findViewById(R.id.tv_nama_dokter_pertemuan);
            this.jenisDokterText = view.findViewById(R.id.tv_jenis_dokter_pertemuan);
            this.keluhanText = view.findViewById(R.id.tv_keluhan);
            this.tanggalText = view.findViewById(R.id.tv_tanggal_pertemuan);
            this.waktuText = view.findViewById(R.id.tv_watu_pertemuan);
            this.delete = view.findViewById(R.id.tv_pertemuan_delete);
            this.i = i;
            this.pp = pp;
        }

        public void updateView(final Pertemuan pertemuan){
            this.namaDokterText.setText(pertemuan.getNamaDokterPertemuan());
            this.jenisDokterText.setText(pertemuan.getJenisDokterPertemuan());
            this.keluhanText.setText(pertemuan.getKeluhanPertemuan());
            this.tanggalText.setText(pertemuan.getTanggalPertemuan());
            this.waktuText.setText(pertemuan.getWaktuPertemuan());
            this.delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(view == delete){
                        pp.deleteItem(i);
                        notifyDataSetChanged();
                    }
                }
            });

        }
    }
}
