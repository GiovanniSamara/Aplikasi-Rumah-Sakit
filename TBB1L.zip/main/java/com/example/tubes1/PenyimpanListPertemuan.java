package com.example.tubes1;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;

public class PenyimpanListPertemuan {
    protected SharedPreferences sharedPref;
    protected final static String NAMA_SHARED_PREF = "sp_list_dokter";
    protected final static String KEY_NAMA = "NAMA";
    protected final static String KEY_JENIS = "JENIS";
    protected final static String KEY_KELUHAN = "KELUHAN";
    protected final static String KEY_TANGGAL = "TANGGAL";
    protected final static String KEY_WAKTU = "WAKTU";

    public PenyimpanListPertemuan(Context context){
        this.sharedPref = context.getSharedPreferences(NAMA_SHARED_PREF, 0);
    }


    public void saveNama(String nama){
        SharedPreferences.Editor editor = this.sharedPref.edit();
        editor.putString(KEY_NAMA, nama);
        editor.commit();
    }

    public String getNama() {
        return sharedPref.getString(KEY_NAMA,"");
    }

    public void saveJenis(String jenis){
        SharedPreferences.Editor editor = this.sharedPref.edit();
        editor.putString(KEY_JENIS, jenis);
        editor.commit();
    }

    public String getJenis() {
        return sharedPref.getString(KEY_JENIS,"");
    }

    public void saveKeluhan(String keluhan){
        SharedPreferences.Editor editor = this.sharedPref.edit();
        editor.putString(KEY_KELUHAN, keluhan);
        editor.commit();
    }

    public String getKeluhan() {
        return sharedPref.getString(KEY_KELUHAN,"");
    }

    public void saveTanggal(String tanggal){
        SharedPreferences.Editor editor = this.sharedPref.edit();
        editor.putString(KEY_TANGGAL, tanggal);
        editor.commit();
    }

    public String getTanggal() {
        return sharedPref.getString(KEY_TANGGAL,"");
    }

    public void saveWaktu(String waktu){
        SharedPreferences.Editor editor = this.sharedPref.edit();
        editor.putString(KEY_WAKTU, waktu);
        editor.commit();
    }

    public String getWaktu() {
        return sharedPref.getString(KEY_WAKTU,"");
    }
}
