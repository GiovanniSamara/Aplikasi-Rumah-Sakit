package com.example.tubes1;

import static android.content.Context.MODE_PRIVATE;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DokterFragment extends Fragment implements DokterPresenter.IFragmentDokter {
    private FragmentListener fragmentListener;
    private DokterListAdapter adapter;
    private EditText namaDokter;
    private EditText jenisDokter;
    private List<Dokter> dokters;
    private Button tambah;
    private DokterPresenter p;

    public DokterFragment(){

    }

    public static DokterFragment newInstance() {
        DokterFragment fragment = new DokterFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView (LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dokter, container, false);
        ListView listDokter = view.findViewById(R.id.lstDokter);
        loadData();


        this.p = new DokterPresenter(this);
        this.tambah = view.findViewById(R.id.buttonAdd);
        this.namaDokter = view.findViewById(R.id.et_nama_dokter);
        this.jenisDokter = view.findViewById(R.id.et_jenis_dokter);
        dokters = Arrays.asList(DokterList.dokterObjectArr);
        this.adapter = new DokterListAdapter(this, p);
        listDokter.setAdapter(adapter);
        p.loadData();

        this.tambah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveData();
                if(view == tambah){
                    String namaD = namaDokter.getText().toString();
                    String jenisD = jenisDokter.getText().toString();
                    p.addNew(namaD, jenisD);
                    saveData();
                }
            }
        });
        return view;
    }

    private void saveData(){
        SharedPreferences sharedPreferences = getContext().getSharedPreferences("shared preferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(dokters);
        editor.putString("task list", json);
        editor.apply();
    }

    private void loadData(){
        SharedPreferences sharedPreferences = getContext().getSharedPreferences("shared preferences", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("task list", null);
        Type type = new TypeToken<ArrayList<Dokter>>() {}.getType();
        dokters = gson.fromJson(json, type);

        if(dokters == null){
            dokters = new ArrayList<>();
        }
    }

    public void onAttach(Context context){
        super.onAttach(context);
        if(context instanceof FragmentListener){
            this.fragmentListener = (FragmentListener) context;
        } else{
            throw new ClassCastException(context.toString() + " must implement FragmentListener");
        }
    }

    @Override
    public void UpdateList(List<Dokter> data) {
        adapter.updateList(data);
        adapter.notifyDataSetChanged();
    }

    @Override
    public void resetAddForm() {
        namaDokter.setText("");
        jenisDokter.setText("");
    }
}
