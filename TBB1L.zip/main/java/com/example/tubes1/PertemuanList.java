package com.example.tubes1;

public class PertemuanList {
    public static Pertemuan[] pertemuanObjectArr = {
            new Pertemuan("dr Mike", "Internis", "Sakit ginjal", "1 November 2022", "13:00"),
            new Pertemuan("dr Mike", "Internis", "Progres perawatan ginjal", "15 November 2022", "13:00")
    };
}
